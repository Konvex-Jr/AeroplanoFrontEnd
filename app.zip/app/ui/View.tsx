import { MouseEventHandler } from "react"
import { CgClose } from "react-icons/cg";
import { FaFilePdf } from "react-icons/fa";
import { Post, getPostPdfUrl } from "../lib/posts";

interface ViewProps {
    post:    Post
    onClose: MouseEventHandler
}

export default function View({ onClose, post }: ViewProps){

    if(!post) return

    const { id, title, description, username, created_at, original_filename } = post

    const pdfUrl = getPostPdfUrl(id)

    const formattedDate = created_at
        ? new Date(created_at).toLocaleDateString("pt-BR")
        : null

    return (
        // Overlay
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>

            {/* View */}
            <div id={id} className="relative top-0 w-full max-w-4xl h-[80%] overflow-hidden rounded-lg bg-white shadow-xl" onClick={(e) => e.stopPropagation() } >

                <div className="p-6">
                    <div className="flex items-center justify-between border-b pb-4">
                        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
                        <button 
                        onClick={onClose}
                        className="text-gray-500 hover:text-gray-800 transition-colors cursor-pointer"
                        >
                            <CgClose className="h-6 w-6 lg:h-8 lg:w-8" />
                        </button>
                    </div>

                    { (username || formattedDate) &&
                        <div className="mt-2 text-xs text-gray-400" >
                            { username && <span>Por {username}</span> }
                            { username && formattedDate && <span> · </span> }
                            { formattedDate && <span>{formattedDate}</span> }
                        </div>
                    }
                    
                    <div className="mt-4 max-h-[45vh] overflow-y-auto">
                        <p className="text-gray-700 whitespace-pre-wrap">{description}</p>
                    </div>

                    <a
                    href={pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-6 inline-flex items-center gap-2 rounded-lg bg-gray-900 px-4 py-2 text-white text-sm hover:bg-gray-700 transition-colors"
                    >
                        <FaFilePdf className="h-4 w-4" />
                        Ler conteúdo completo{ original_filename ? ` (${original_filename})` : "" }
                    </a>
                </div>

            </div>

        </div>
    )

}
