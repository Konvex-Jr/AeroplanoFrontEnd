// URL base da API do backend. Mesmo padrão usado em app/api/login/route.ts.
const API_URL = process.env.BACKEND_URL ?? "http://localhost:8000";

export interface Post {
    id: string
    title: string
    description: string
    image: string
    file_size: number
    original_filename: string
    created_at: string
    updated_at: string
    username: string
}

interface GetAllPostsResponse {
    data: Post[]
}

/**
 * Busca os posts do blog diretamente no backend.
 * Usado em Server Components (ex: app/blog/page.tsx).
 *
 * @param search - Data opcional no formato YYYY-MM-DD para filtrar os posts.
 */
export async function getPosts(search?: string): Promise<Post[]> {

    const url = new URL("/api/posts", API_URL)
    if (search) url.searchParams.set("search", search)

    try {

        const res = await fetch(url.toString(), {
            method: "GET",
            headers: { "Content-Type": "application/json" },
            cache: "no-store"
        })

        // O backend retorna 422 (com AppError) quando não há posts cadastrados.
        if (!res.ok) return []

        const body: GetAllPostsResponse = await res.json()

        return body?.data ?? []

    } catch (error: any) {

        console.log(error);

        return []
    }
}

/**
 * Monta a URL pública de streaming do PDF de um post.
 * Endpoint público no backend: GET /api/posts/:id/pdf
 */
export function getPostPdfUrl(id: string): string {
    return new URL(`/api/posts/${id}/pdf`, API_URL).toString()
}
