import { NextRequest, NextResponse } from "next/server";

// Handler de Posts.

const API_URL = process.env.BACKEND_URL ?? "http://localhost:8000";

export async function GET(request: NextRequest) {

    const search = request.nextUrl.searchParams.get("search")

    const url = new URL("/api/posts", API_URL)
    if (search) url.searchParams.set("search", search)

    try {

        const res: Response = await fetch(url.toString(), {
            method: "GET",
            headers: { 'Content-Type': 'application/json' },
        })

        if (!res.ok) {
            const errorBody = await res.json().catch(() => null)
            return NextResponse.json(
                { message: errorBody?.message ?? "Não há posts." },
                { status: res.status }
            )
        }

        return res

    } catch (error: any) {

        console.log(error);

        return NextResponse.json({ message: "Ocorreu Algo de Errado." }, { status: 400 })
    }

}

// Cadastro de Post — admin only (validado no backend via cookie httpOnly 'access-token')

export async function POST(request: NextRequest) {

    try {

        const formData = await request.formData()

        // Repassa o cookie da requisição original para o backend, já que o
        // fetch server-to-server não herda automaticamente os cookies do browser.
        const cookie = request.headers.get('cookie') ?? ''

        const res: Response = await fetch(new URL("/api/posts", API_URL).toString(), {
            method: "POST",
            headers: { cookie },
            body: formData,
        })

        return res

    } catch (error: any) {

        console.log(error);

        return NextResponse.json({ message: "Ocorreu Algo de Errado." }, { status: 400 })
    }

}
